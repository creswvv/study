namespace LibrarySystem;

/// <summary>Книга (задачи 1, 3, 5, 7, 8).</summary>
public class Book
{
    public string Title { get; private set; }
    public string Author { get; }
    public int Year { get; }

    public bool IsAvailable { get; private set; } = true;
    public string? BorrowedBy { get; private set; }
    public DateTime? BorrowDate { get; private set; }
    public DateTime? DueDate { get; private set; }

    public Book(string title, string author, int year)
    {
        Title = title.Trim();
        Author = author.Trim();
        Year = year;
    }

    // Задача 1. Вывод информации о книге.
    public void DisplayInfo()
    {
        string status = IsAvailable
            ? "в наличии"
            : $"выдана: {BorrowedBy}, вернуть до {DueDate:dd.MM.yyyy}";
        Console.WriteLine($"«{Title}» — {Author}, {Year} г. [{status}]");
    }

    // Задача 3. Метод с одним параметром.
    public void SetTitle(string title)
    {
        if (string.IsNullOrWhiteSpace(title))
        {
            Console.WriteLine("Название не может быть пустым.");
            return;
        }
        Title = title.Trim();
    }

    // Задача 7. Метод проверки: true — книга доступна, false — выдана.
    public bool IsBookAvailable() => IsAvailable;

    // Задача 8. Возраст книги по году издания.
    public int CalculateBookAge(int year) => Math.Max(0, DateTime.Now.Year - year);

    // Служебные методы: меняют статус книги (вызываются из Library).
    internal void Lend(string readerName, DateTime borrowDate, int loanDays)
    {
        IsAvailable = false;
        BorrowedBy = readerName;
        BorrowDate = borrowDate;
        DueDate = borrowDate.AddDays(loanDays);
    }

    internal void Receive()
    {
        IsAvailable = true;
        BorrowedBy = null;
        BorrowDate = null;
        DueDate = null;
    }
}
