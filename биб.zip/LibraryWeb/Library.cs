namespace LibrarySystem;

/// <summary>Библиотека: книги, читатели, выдача и возврат.</summary>
public class Library
{
    // ---------- Статические члены (задачи 11, 13, 14, 15) ----------
    public static readonly string LibraryName = "Центральная городская библиотека";
    public const int LoanDays = 14;     // срок выдачи книги
    public const int FinePerDay = 5;    // штраф за один день просрочки (у.е.)

    /// <summary>Задача 15. Статический счётчик: сколько книг добавлено за всё время.</summary>
    public static int TotalBooks { get; private set; }

    private readonly List<Book> _books = new();
    private readonly List<Reader> _readers = new();

    /// <summary>Куда выводить сообщения: по умолчанию в консоль (для сайта подменяется).</summary>
    public Action<string> Log { get; set; } = Console.WriteLine;

    public IReadOnlyList<Book> Books => _books;
    public IReadOnlyList<Reader> Readers => _readers;

    // Задача 11. Статический метод — вызывается без создания объекта: Library.ShowLibraryName().
    public static void ShowLibraryName() => Console.WriteLine($"Библиотека: «{LibraryName}»");

    // Задача 13. Статический метод расчёта штрафа.
    public static int CalculateFine(int overdueDays) => overdueDays <= 0 ? 0 : overdueDays * FinePerDay;

    // Задача 14. Статический метод: большее из двух количеств книг.
    public static int GetMaxBooks(int first, int second) => Math.Max(first, second);

    // Задача 15. Метод, увеличивающий статический счётчик.
    public static void IncreaseTotalBooks() => TotalBooks++;

    // ---------- Базовые методы (задачи 2, 4, 6) ----------

    // Задача 2. Метод без параметров.
    public void ShowWelcomeMessage()
    {
        Log("==============================================");
        Log($"  Добро пожаловать в «{LibraryName}»!");
        Log("  Читайте, узнавайте новое, возвращайте вовремя.");
        Log("==============================================");
    }

    // Задача 4. Метод с несколькими параметрами. Возвращает true, если книга добавлена.
    public bool AddBook(string title, string author, int year)
    {
        if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(author))
        {
            Log("Название и автор не могут быть пустыми.");
            return false;
        }
        if (year < 1 || year > DateTime.Now.Year)
        {
            Log($"Некорректный год издания (допустимо 1–{DateTime.Now.Year}).");
            return false;
        }
        if (FindBook(title) != null)
        {
            Log($"Книга «{title.Trim()}» уже есть в библиотеке.");
            return false;
        }

        _books.Add(new Book(title, author, year));
        IncreaseTotalBooks();                      // задача 15
        Log($"Книга «{title.Trim()}» добавлена.");
        return true;
    }

    // Задача 6. Количество книг в библиотеке.
    public int GetBookCount() => _books.Count;

    // ---------- Проверки и поиск (задачи 9, 10) ----------

    // Задача 9. Поиск книги по точному названию (без учёта регистра). null — не найдена.
    public Book? FindBook(string title) =>
        _books.FirstOrDefault(b => b.Title.Equals(title.Trim(), StringComparison.OrdinalIgnoreCase));

    // Задача 10. Проверка наличия читателя в системе.
    public bool IsReaderRegistered(string name) => FindReader(name) != null;

    private Reader? FindReader(string name)
    {
        name = name.Trim();
        return _readers.FirstOrDefault(r => r.FullName.Equals(name, StringComparison.OrdinalIgnoreCase))
            ?? _readers.FirstOrDefault(r => r.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
    }

    // ---------- Нестатические методы (задачи 12, 14) ----------

    // Задача 12. Список книг конкретной библиотеки.
    public void ShowBooks()
    {
        if (_books.Count == 0)
        {
            Log("В библиотеке пока нет книг.");
            return;
        }
        for (int i = 0; i < _books.Count; i++)
        {
            Console.Write($"{i + 1}. ");
            _books[i].DisplayInfo();
        }
    }

    // Задача 14. Количество доступных (не выданных) книг.
    public int GetAvailableBooks() => _books.Count(b => b.IsAvailable);

    // ---------- Перегрузка (задачи 16, 17) ----------

    // Задача 16. Три метода SearchBook().
    public List<Book> SearchBook(string title) =>
        _books.Where(b => b.Title.Contains(title.Trim(), StringComparison.OrdinalIgnoreCase)).ToList();

    public List<Book> SearchBook(Author author) =>
        _books.Where(b => b.Author.Contains(author.Name.Trim(), StringComparison.OrdinalIgnoreCase)).ToList();

    public List<Book> SearchBook(int year) =>
        _books.Where(b => b.Year == year).ToList();

    // Задача 17. Три варианта AddReader().
    public bool AddReader(string name) =>
        RegisterReader(new Reader(name));

    public bool AddReader(string name, string lastName) =>
        RegisterReader(new Reader(name, lastName));

    public bool AddReader(string name, PhoneNumber phone) =>
        RegisterReader(new Reader(name, phone: phone.Value));

    // Дополнительный вариант (сверх ТЗ): имя, фамилия и телефон сразу.
    public bool AddReader(string name, string lastName, PhoneNumber phone) =>
        RegisterReader(new Reader(name, lastName, phone.Value));

    private bool RegisterReader(Reader reader)
    {
        if (string.IsNullOrWhiteSpace(reader.Name))
        {
            Log("Имя читателя не может быть пустым.");
            return false;
        }
        if (IsReaderRegistered(reader.FullName))
        {
            Log($"Читатель «{reader.FullName}» уже зарегистрирован.");
            return false;
        }
        _readers.Add(reader);
        Log($"Читатель «{reader.FullName}» зарегистрирован.");
        return true;
    }

    // ---------- Выдача и возврат (задачи 18, 21, 22) ----------

    // Задача 18. Простой возврат: только если книга ранее была выдана.
    public bool ReturnBook(string title)
    {
        Book? book = FindBook(title);
        if (book == null)
        {
            Log("Такой книги нет в библиотеке.");
            return false;
        }
        if (book.IsAvailable)
        {
            Log($"Книга «{book.Title}» не выдавалась — возвращать нечего.");
            return false;
        }
        book.Receive();
        Log($"Книга «{book.Title}» возвращена.");
        return true;
    }

    // Задача 22. Возврат с проверкой статуса и расчётом штрафа за просрочку.
    public bool ReturnBook(string title, DateTime returnDate, out int fine)
    {
        fine = 0;
        Book? book = FindBook(title);
        if (book == null)
        {
            Log("Такой книги нет в библиотеке.");
            return false;
        }
        if (book.IsAvailable)
        {
            Log($"Книга «{book.Title}» не выдавалась — возвращать нечего.");
            return false;
        }

        int overdueDays = (returnDate.Date - book.DueDate!.Value.Date).Days;
        fine = CalculateFine(overdueDays);
        string reader = book.BorrowedBy!;
        book.Receive();

        Log($"Книга «{book.Title}» принята от читателя {reader}.");
        if (fine > 0)
            Log($"Просрочка: {overdueDays} дн. Штраф: {fine} у.е.");
        else
            Log("Книга возвращена в срок, штрафа нет.");
        return true;
    }

    // Задача 21. Выдача книги: проверяет книгу, читателя и оформляет выдачу.
    public bool BorrowBook(string title, string readerName)
    {
        Book? book = FindBook(title);
        if (book == null)
        {
            Log("Такой книги нет в библиотеке.");
            return false;
        }
        Reader? reader = FindReader(readerName);
        if (reader == null)
        {
            Log($"Читатель «{readerName.Trim()}» не зарегистрирован.");
            return false;
        }
        if (!book.IsBookAvailable())
        {
            Log($"Книга «{book.Title}» уже выдана ({book.BorrowedBy}).");
            return false;
        }

        book.Lend(reader.FullName, DateTime.Now, LoanDays);
        Log($"Книга «{book.Title}» выдана читателю {reader.FullName} до {book.DueDate:dd.MM.yyyy}.");
        return true;
    }

    // ---------- Рекурсия и сортировка (задачи 19, 20) ----------

    // Задача 19. Рекурсивный подсчёт книг в списке.
    public int CountBooksRecursive() => CountRecursive(0);

    private int CountRecursive(int index) =>
        index >= _books.Count ? 0 : 1 + CountRecursive(index + 1);

    // Задача 20. Сортировка книг по году издания (по возрастанию).
    public void SortBooksByYear() => _books.Sort((a, b) => a.Year.CompareTo(b.Year));

    // ---------- Статистика и меню (задачи 23, 24) ----------

    // Задача 23.
    public void ShowStatistics()
    {
        int total = GetBookCount();
        int available = GetAvailableBooks();
        Log("----- Статистика -----");
        Log($"Всего книг:               {total}");
        Log($"Доступно:                 {available}");
        Log($"Выдано:                   {total - available}");
        Log($"Зарегистрировано читателей: {_readers.Count}");
    }

    // Задача 24.
    public void ShowMenu()
    {
        Log("");
        Log("============ ГЛАВНОЕ МЕНЮ ============");
        Log("1. Добавить книгу");
        Log("2. Показать все книги");
        Log("3. Найти книгу");
        Log("4. Зарегистрировать читателя");
        Log("5. Выдать книгу");
        Log("6. Вернуть книгу");
        Log("7. Показать статистику");
        Log("8. Завершить программу");
        Log("======================================");
        Console.Write("Ваш выбор: ");
    }
}
