namespace LibrarySystem;

/// <summary>
/// Автор книги. Отдельный тип нужен, чтобы можно было сделать перегрузку
/// SearchBook(string title) / SearchBook(Author author) / SearchBook(int year):
/// в C# нельзя перегрузить методы только по имени параметра.
/// </summary>
public readonly record struct Author(string Name);

/// <summary>Номер телефона (отдельный тип для перегрузки AddReader).</summary>
public readonly record struct PhoneNumber(string Value);

/// <summary>Читатель библиотеки.</summary>
public class Reader
{
    public string Name { get; }
    public string? LastName { get; }
    public string? Phone { get; }

    public Reader(string name, string? lastName = null, string? phone = null)
    {
        Name = name.Trim();
        LastName = string.IsNullOrWhiteSpace(lastName) ? null : lastName.Trim();
        Phone = string.IsNullOrWhiteSpace(phone) ? null : phone.Trim();
    }

    public string FullName => LastName is null ? Name : $"{Name} {LastName}";

    public void DisplayInfo()
    {
        string phone = Phone is null ? "" : $", тел.: {Phone}";
        Console.WriteLine($"Читатель: {FullName}{phone}");
    }
}
