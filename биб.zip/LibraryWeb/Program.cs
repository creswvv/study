using LibrarySystem;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// Одна библиотека на всё приложение (данные живут, пока запущен сервер).
var library = new Library();
var sync = new object();
var messages = new List<string>();
library.Log = m => messages.Add(m);   // сообщения Library попадают не в консоль, а в ответ сайту

lock (sync)
{
    library.AddBook("Война и мир", "Лев Толстой", 1869);
    library.AddBook("Преступление и наказание", "Фёдор Достоевский", 1866);
    library.AddBook("Мастер и Маргарита", "Михаил Булгаков", 1967);
    library.AddBook("1984", "Джордж Оруэлл", 1949);
    library.AddReader("Айдар", "Сериков");
    library.AddReader("Мария");
    messages.Clear();
}

app.UseDefaultFiles();   // открывает wwwroot/index.html
app.UseStaticFiles();

// Выполняет действие и возвращает сайту результат и сообщение от Library.
IResult Run(Func<bool> action)
{
    lock (sync)
    {
        messages.Clear();
        bool ok = action();
        return Results.Ok(new { ok, message = string.Join(" ", messages) });
    }
}

object BookDto(Book b) => new
{
    b.Title,
    b.Author,
    b.Year,
    Age = b.CalculateBookAge(b.Year),
    b.IsAvailable,
    b.BorrowedBy,
    Due = b.DueDate?.ToString("dd.MM.yyyy")
};

// ----- Данные для страницы -----
app.MapGet("/api/state", () =>
{
    lock (sync)
    {
        return Results.Ok(new
        {
            libraryName = Library.LibraryName,
            loanDays = Library.LoanDays,
            finePerDay = Library.FinePerDay,
            stats = new
            {
                total = library.GetBookCount(),
                available = library.GetAvailableBooks(),
                borrowed = library.GetBookCount() - library.GetAvailableBooks(),
                readers = library.Readers.Count,
                totalAdded = Library.TotalBooks
            },
            books = library.Books.Select(BookDto).ToList(),
            readers = library.Readers.Select(r => new { r.FullName, r.Phone }).ToList()
        });
    }
});

// ----- Поиск (три перегрузки SearchBook) -----
app.MapGet("/api/search", (string by, string q) =>
{
    lock (sync)
    {
        List<Book> found;
        if (by == "author") found = library.SearchBook(new Author(q));
        else if (by == "year" && int.TryParse(q, out int year)) found = library.SearchBook(year);
        else if (by == "title") found = library.SearchBook(q);
        else found = new List<Book>();
        return Results.Ok(found.Select(BookDto).ToList());
    }
});

// ----- Действия -----
app.MapPost("/api/books", (BookRequest r) =>
    Run(() => library.AddBook(r.Title ?? "", r.Author ?? "", r.Year)));

app.MapPost("/api/sort", () =>
    Run(() => { library.SortBooksByYear(); return true; }));

app.MapPost("/api/readers", (ReaderRequest r) => Run(() =>
{
    string name = r.Name ?? "";
    bool hasLast = !string.IsNullOrWhiteSpace(r.LastName);
    bool hasPhone = !string.IsNullOrWhiteSpace(r.Phone);

    if (hasLast && hasPhone) return library.AddReader(name, r.LastName!, new PhoneNumber(r.Phone!));
    if (hasLast) return library.AddReader(name, r.LastName!);
    if (hasPhone) return library.AddReader(name, new PhoneNumber(r.Phone!));
    return library.AddReader(name);
}));

app.MapPost("/api/borrow", (BorrowRequest r) =>
    Run(() => library.BorrowBook(r.Title ?? "", r.ReaderName ?? "")));

app.MapPost("/api/return", (ReturnRequest r) => Run(() =>
{
    string title = r.Title ?? "";
    DateTime returnDate = DateTime.Now;

    // Позволяет проверить штраф без реальной просрочки.
    Book? book = library.FindBook(title);
    if (r.Days is int days && days >= 0 && book?.BorrowDate != null)
        returnDate = book.BorrowDate.Value.AddDays(days);

    return library.ReturnBook(title, returnDate, out _);
}));

app.Run();

record BookRequest(string? Title, string? Author, int Year);
record ReaderRequest(string? Name, string? LastName, string? Phone);
record BorrowRequest(string? Title, string? ReaderName);
record ReturnRequest(string? Title, int? Days);
